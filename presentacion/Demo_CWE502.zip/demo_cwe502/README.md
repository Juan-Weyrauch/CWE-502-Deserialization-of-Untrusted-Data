# Demo local de CWE-502

## Objetivo y alcance
Comparar una importacion con pickle y otra con JSON. La entrada preparada llama
a print durante pickle.loads; despues devuelve None y la comprobacion de tipo
la rechaza. Esto demuestra una llamada controlada, no robo de informacion,
ejecucion de comandos ni un ataque remoto. En otros escenarios el impacto depende
del entorno y de los permisos. No todos los casos de CWE-502 ejecutan codigo.

## Preparacion en Windows
Requisito previsto: Python 3.14.5, confirmado por el usuario. Solo biblioteca
estandar, sin pip, Docker, servidor ni permisos de administrador. Probado por
el asistente en Python 3.12.14; falta ejecucion en la maquina del usuario.

Extraer el ZIP completo. Abrir la carpeta demo_cwe502 que contiene demo.py,
test_demo.py y este README. Abrir PowerShell en esa carpeta (desde el Explorador,
escribir powershell en la barra de direcciones y pulsar Enter). No trabajar en
System32. Ejecutar `dir` para comprobar que aparece demo.py.

## Comandos y resultados
Ejecutar cada comando en esa carpeta:

```powershell
py demo.py vulnerable legitimo
```
Serializa y recupera el personaje. Muestra [1], [2] y ACEPTADO con Juan, 8, 75.

```powershell
py demo.py vulnerable manipulado
```
Genera bytes preparados dentro del laboratorio y los entrega al importador.
Salida esperada:

```text
[1] Antes de pickle.loads
[EFECTO] Se llamo a print DURANTE la deserializacion.
[2] Despues de pickle.loads
RECHAZADO: Tipo rechazado, pero el efecto ya pudo ocurrir.
```

```powershell
py demo.py vulnerable malformado
py demo.py mitigado legitimo
py demo.py mitigado invalido
py demo.py mitigado manipulado
py demo.py mitigado texto
py demo.py mitigado pickle
py demo.py mitigado malformado
```
En orden: pickle rechaza bytes rotos; JSON acepta el personaje legitimo; rechaza
vida negativa; rechaza un campo extra llamado funcion; acepta print("HOLA") como
nombre literal sin ejecutarlo; rechaza el pickle por formato incompatible; rechaza
JSON roto. Los rechazos intencionales devuelven codigo de salida 1, no indican
que fallo la instalacion. `texto` puede mostrar HOLA dentro del nombre al imprimir
el personaje: eso es mostrar datos, no ejecutar ese texto.

## Pruebas
```powershell
py -m unittest -v
```
Resultado esperado: 5 pruebas, OK. Incluyen equivalencia de personajes legitimos,
efecto entre los marcadores antes/despues, ausencia de efecto en la version
mitigada, texto que no se ejecuta, limites y tipos incorrectos.

## Recorrido del codigo
1. main lee version y caso desde la terminal.
2. generar_entrada representa al emisor: produce bytes pickle o JSON.
3. El importador recibe solamente bytes, no el nombre del caso. No hay un if
   de ataque dentro del importador: el efecto lo ejecuta realmente pickle.
4. importar_vulnerable llama pickle.loads antes de comprobar el tipo.
5. importar_mitigado limita bytes, lee UTF-8/JSON, exige campos exactos, valida
   tipos/rangos y construye Personaje explicitamente.

## Si el docente me pregunta que hace esta linea de codigo
- @dataclass: genera inicializacion, representacion y comparacion del personaje.
- __reduce__: al serializar, describe como reconstruir un valor. Retorna la
  funcion print y una tupla con su argumento; no llama a print en ese momento.
- (MARCA,): tupla de un elemento; la coma es necesaria.
- pickle.dumps: genera bytes. Se fija protocolo 4 para evitar depender del
  protocolo por defecto de una version concreta.
- pickle.loads: reconstruye el valor; aqui ejecuta la llamada indicada por los
  bytes. print ya existe en Python, no se envia su implementacion en el archivo.
- type(objeto) is not Personaje: comprobacion posterior insuficiente para evitar
  efectos ocurridos dentro de loads. En esta demo print retorna None.
- json.loads: obtiene datos simples; no interpreta el nombre como codigo.
- set(valores): permite exigir exactamente las tres claves previstas.
- type(nivel) is int: exige entero y excluye booleanos, aunque bool hereda de int.
- Personaje(...): la aplicacion elige el tipo y la construccion.

## Mitigacion y limites
La correccion principal es eliminar pickle de la entrada no confiable, no solo
agregar validaciones posteriores. No existe fallback a pickle ni eval de los
textos JSON. Validar tipos y rangos es una capa adicional. No basta con rechazar
el pickle por ser incompatible: los casos JSON muestran funcionalidad legitima,
esquema estricto y texto que permanece como dato.

El limite de 4096 bytes se aplica a bytes ya recibidos en memoria. En un servicio
real tambien debe limitarse la lectura de red/archivo antes de acumularlos.
No se implementan identidad, autorizacion ni prueba de que el nivel fue ganado;
un valor valido no demuestra un derecho. Un despliegue requeriria controles de
recursos apropiados, dependencias mantenidas y privilegios minimos.

## Errores frecuentes
- No se encuentra demo.py: comprobar con dir y abrir PowerShell en la carpeta
  extraida correcta, no dentro del ZIP ni en System32.
- py no reconocido: usar python en los mismos comandos; ya fue comprobado por
  el usuario. No instalar paquetes para esta demo.
- No aparece [EFECTO]: comprobar que se uso vulnerable manipulado; en mitigado
  no debe aparecer.
- Para terminar: cada comando finaliza solo. No hay servicio que detener.

## Seguridad
Usar solo las entradas de prueba incluidas. No adaptar el importador vulnerable
para cargar archivos pickle de terceros. La demo no usa red ni escribe archivos
de usuario; unittest puede crear cache normal de Python en la carpeta del proyecto.

## Fuentes
- https://cwe.mitre.org/data/definitions/502.html
- https://docs.python.org/3.14/library/pickle.html
- https://docs.python.org/3.14/library/json.html
- https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html
